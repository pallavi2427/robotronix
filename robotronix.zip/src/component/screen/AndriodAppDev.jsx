import React from "react";

const AndriodAppDev = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-12 section-divide">
            <h1>Andriod App Development</h1>
          </div>
        </div>
      </div>
    </>
  );
};

export default AndriodAppDev;
