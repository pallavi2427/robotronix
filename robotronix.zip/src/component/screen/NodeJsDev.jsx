import React from "react";

const NodeJsDev = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-12 section-divide">Node js Development</div>
        </div>
      </div>
    </>
  );
};

export default NodeJsDev;
