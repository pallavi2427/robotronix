import React from "react";

const MeanDev = () => {
  return (
    <>
      <div className="container">
      <div className="row">
        <div className="col-12 section-divide">MeanDev</div>
      </div>
      </div>
    </>
  );
};

export default MeanDev;
