import React from "react";

const ReactNativeAppDev = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-12 section-divide">
            <h1>React Native App Development</h1>
          </div>
        </div>
      </div>
    </>
  );
};

export default ReactNativeAppDev;
