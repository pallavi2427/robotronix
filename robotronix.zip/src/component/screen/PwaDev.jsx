import React from "react";

const PwaDev = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-12 section-divide">
            Progressive Web Development
          </div>
        </div>
      </div>
    </>
  );
};

export default PwaDev;
