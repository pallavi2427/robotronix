import React from "react";

import Slider from "./Slider";

export const Home = () => {
  return (
    <>

      <Slider />
    </>
  );
};
